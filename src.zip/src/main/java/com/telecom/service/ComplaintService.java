package com.telecom.service;

import java.util.List;

import com.telecom.dao.ComplaintDao;
import com.telecom.entity.Complaint;
import com.telecom.entity.Customer;
import com.telecom.entity.Engineer;
import com.telecom.entity.Manager;
import com.telecom.model.ComplaintModel;
import com.telecom.model.CustomerModel;
import com.telecom.model.EngineerModel;
import com.telecom.model.ManagerModel;

public class ComplaintService {
private ComplaintDao complaintDao = new ComplaintDao();

public void addComplaint(ComplaintModel complaint) {
	Complaint complaints = new Complaint();
	complaints.setComplaintType(complaint.getComplaintType());
	complaints.setDescription(complaint.getDescription());
	complaintDao.insertComplaint(complaints);
	
}

public List<Complaint> getComplaintsCustomer(CustomerModel model) {
	Customer customer = new Customer(model);
	return complaintDao.getComplaintsByCustomer(customer);
}

public List<Complaint> getComplaintsManager(ManagerModel model) {
	Manager manager = new Manager(model);
	return complaintDao.getComplaintsByManager(manager);
}

public List<Complaint> getComplaintsEngineer(EngineerModel model) {
	Engineer engineer = new Engineer(model);
	return complaintDao.getComplaintsByEngineer(engineer);
}

}
