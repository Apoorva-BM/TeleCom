package com.telecom.service;

import com.telecom.dao.AdminDao;
import com.telecom.dao.CustomerDao;
import com.telecom.dao.EngineerDao;
import com.telecom.dao.ManagerDao;
import com.telecom.entity.Admin;
import com.telecom.entity.Customer;
import com.telecom.entity.Engineer;
import com.telecom.entity.Manager;
import com.telecom.model.UserModel;

public class UserService {
private AdminDao adminDao = new AdminDao();
private CustomerDao customerDao = new CustomerDao();
private ManagerDao managerDao = new ManagerDao();
private EngineerDao engineerDao = new EngineerDao();

public void addAdmin(UserModel user) {
	Admin admin = new Admin();
	admin.setAdminUserName(user.getUserName());
	admin.setAdminPassword(user.getPassword());
	adminDao.insertAdmin(admin);
}

public void addManager(UserModel user) {
	Manager manager =new Manager();
	manager.setMngUserName(user.getUserName());
	manager.setMngPassword(user.getPassword());
	managerDao.insertManager(manager);
}

public void addEngineer(UserModel user) {
	Engineer engineer = new Engineer();
	engineer.setEngUserName(user.getUserName());
	engineer.setEngPassword(user.getPassword());
	engineerDao.insertEngineer(engineer);
}

public void addCustomer(UserModel user) {
	Customer customer = new Customer();
	customer.setCustomerUserName(user.getUserName());
	customer.setCustomerPassword(user.getPassword());
	customerDao.insertCustomer(customer);
	}

public Admin getAdmin(String userName, String password) {
	return adminDao.getAdmin(userName, password);
}

public Manager getManager(String userName, String password ) {
	return managerDao.getManager(userName, password);
}

public Customer getCustomer(String userName, String password) {
	return customerDao.getCustomer(userName, password);
}

public Engineer getEngineer(String userName, String password) {
	return engineerDao.getEngineer(userName, password);
}


}
