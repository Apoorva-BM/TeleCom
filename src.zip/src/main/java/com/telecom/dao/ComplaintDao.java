package com.telecom.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.telecom.Config.HibConfig;
import com.telecom.entity.Complaint;
import com.telecom.entity.Customer;
import com.telecom.entity.Engineer;
import com.telecom.entity.Manager;

public class ComplaintDao {

	public void insertComplaint(Complaint complaint) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			session.save(complaint);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		session.close();
		
	}

    public List<Complaint> getComplaintsByCustomer(Customer customer) {
    	 SessionFactory factory=null;
		 Session session=null;
		 Transaction tx = null;
		 Complaint complaints =null;
		
			 factory=HibConfig.getSessionFactory();
				session=factory.openSession();
	            tx = session.beginTransaction();
        Query<Complaint> query = session.createQuery("FROM com.telecom.entity.Complaint c WHERE c.customer = :customer", Complaint.class);
        query.setParameter("customer", customer);
        return query.getResultList();
    }

    public List<Complaint> getComplaintsByManager(Manager manager) {
    	 SessionFactory factory=null;
		 Session session=null;
		 Transaction tx = null;
		 Complaint complaints =null;
		
			 factory=HibConfig.getSessionFactory();
				session=factory.openSession();
	            tx = session.beginTransaction();
        Query<Complaint> query = session.createQuery("FROM com.telecom.entity.Complaint c WHERE c.manager = :manager", Complaint.class);
        query.setParameter("manager", manager);
        return query.getResultList();
    }

    public List<Complaint> getComplaintsByEngineer(Engineer engineer) {
    	 SessionFactory factory=null;
		 Session session=null;
		 Transaction tx = null;
		 Complaint complaints =null;
	
			 factory=HibConfig.getSessionFactory();
				session=factory.openSession();
	            tx = session.beginTransaction();
        Query<Complaint> query = session.createQuery("FROM com.telecom.entity.Complaint c WHERE c.engineer = :engineer", Complaint.class);
        query.setParameter("engineer", engineer);
        return query.getResultList();
    }
	
	 public void deleteComplaint(Complaint complaint ) {
		 SessionFactory factory=null;
		 Session session=null;
		 Transaction tx = null;
		 Complaint complaints =null;
		 try {
			 factory=HibConfig.getSessionFactory();
				session=factory.openSession();
	            tx = session.beginTransaction();

	            Query<Complaint> query = session.createQuery("FROM  com.telecom.entity.Complaint c WHERE c.complaint = :complaint", Complaint.class);
	            query.setParameter("complaint", complaints);
	            complaints = query.uniqueResult();

	            if (complaint != null) {

	                session.delete(complaint);
	                System.out.println("Complaint " + complaint + " deleted successfully");
	            } else {
	                System.out.println("Complaint not found  " + complaint);
	            }

	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) {
	                tx.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	
	            session.close();
	        }
	    }
}
