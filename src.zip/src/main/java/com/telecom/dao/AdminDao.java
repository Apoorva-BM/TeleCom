package com.telecom.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.telecom.Config.HibConfig;
import com.telecom.entity.Admin;

public class AdminDao {

	public void insertAdmin(Admin admin) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			session.save(admin);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		session.close();
		
	}
	
	public Admin getAdmin(String adminUserName,String password) {
		SessionFactory factory=null;
		Session session=null;
		Query<Admin> query=null;
		Admin admin =null;
		try
		{
		factory=HibConfig.getSessionFactory();
		session=factory.openSession();
		query=session.createQuery("select u from com.telecom.entity.Admin u where u.adminUserName=?1 and u.adminPassword=?2", Admin.class);
		query.setParameter(1, adminUserName);
		query.setParameter(2, password);
		admin=query.uniqueResult();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			session.close();
		}
		return admin;
	}
	
	 public void deleteUser(String username) {
		 SessionFactory factory=null;
		 Session session=null;
		 Transaction tx = null;
		 Admin admin =null;
		 try {
			 factory=HibConfig.getSessionFactory();
				session=factory.openSession();
	            tx = session.beginTransaction();

	            Query<Admin> query = session.createQuery("FROM  com.telecom.entity.Admin WHERE username = :adminUserName", Admin.class);
	            query.setParameter("username", username);
	            admin = query.uniqueResult();

	            if (admin != null) {

	                session.delete(admin);
	                System.out.println("User with username " + username + " deleted successfully");
	            } else {
	                System.out.println("User not found with username: " + username);
	            }

	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) {
	                tx.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	
	            session.close();
	        }
	    }
	 
}

