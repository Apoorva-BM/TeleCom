package com.telecom.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.telecom.Config.HibConfig;
import com.telecom.entity.Customer;
import com.telecom.entity.Engineer;

public class EngineerDao {

	public void insertEngineer(Engineer engineer) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			session.save(engineer);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		session.close();
		
	}
	
	public Engineer getEngineer(String userName,String password) {
		SessionFactory factory=null;
		Session session=null;
		Query<Engineer> query=null;
		Engineer engineer =null;
		try
		{
		factory=HibConfig.getSessionFactory();
		session=factory.openSession();
		query=session.createQuery("select u from com.telecom.entity.Engineer u where u.engUserName=?1 and u.engPassword=?2",Engineer.class);
		query.setParameter(1, userName);
		query.setParameter(2, password);
		engineer=query.uniqueResult();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			session.close();
		}
		return engineer;
	}
	
	 public void deleteUser(String username) {
		 SessionFactory factory=null;
		 Session session=null;
		 Transaction tx = null;
		 Engineer engineer =null;
		 try {
			 factory=HibConfig.getSessionFactory();
				session=factory.openSession();
	            tx = session.beginTransaction();

	            Query<Engineer> query = session.createQuery("FROM  com.telecom.entity.Engineer WHERE username = :engUserName", Engineer.class);
	            query.setParameter("username", username);
	            engineer = query.uniqueResult();

	            if (engineer != null) {

	                session.delete(engineer);
	                System.out.println("User with username " + username + " deleted successfully");
	            } else {
	                System.out.println("User not found with username: " + username);
	            }

	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) {
	                tx.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	
	            session.close();
	        }
	    }
}
