package com.telecom.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.telecom.Config.HibConfig;
import com.telecom.entity.Admin;
import com.telecom.entity.Engineer;
import com.telecom.entity.Manager;

public class ManagerDao {

	public void insertManager(Manager manager) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			session.save(manager);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		session.close();
	}
	
	public Manager  getManager(String userName,String password) {
		SessionFactory factory=null;
		Session session=null;
		Query<Manager> query=null;
		Manager manager  =null;
		try
		{
		factory=HibConfig.getSessionFactory();
		session=factory.openSession();
		query=session.createQuery("select u from com.telecom.entity.Manager u where u.mngUserName=?1 and u.mngPassword=?2", Manager.class);
		query.setParameter(1, userName);
		query.setParameter(2, password);
		manager=query.uniqueResult();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			session.close();
		}
		return manager;
	}
	
	 public void deleteUser(String username) {
		 SessionFactory factory=null;
		 Session session=null;
		 Transaction tx = null;
		 Manager manager =null;
		 try {
			 factory=HibConfig.getSessionFactory();
				session=factory.openSession();
	            tx = session.beginTransaction();

	            Query<Manager> query = session.createQuery("FROM com.telecom.entity.Manager WHERE username = :mngUserName", Manager.class);
	            query.setParameter("username", username);
	            manager = query.uniqueResult();

	            if (manager != null) {

	                session.delete(manager);
	                System.out.println("User with username " + username + " deleted successfully");
	            } else {
	                System.out.println("User not found with username: " + username);
	            }

	            tx.commit();
	        } catch (Exception e) {
	            if (tx != null) {
	                tx.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	
	            session.close();
	        }
	    }
}
