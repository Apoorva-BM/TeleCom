package com.telecom.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.telecom.entity.Admin;
import com.telecom.entity.Customer;
import com.telecom.entity.Engineer;
import com.telecom.entity.Manager;
import com.telecom.model.LoginModel;
import com.telecom.service.UserService;

@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserService userService  = new UserService();
       
	 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			String username=request.getParameter("username");
			String password=request.getParameter("password");
			String role = request.getParameter("role");
			LoginModel model=new LoginModel();
			model.setUsername(username);
			model.setPassword(password);
			model.setRole(role);
			if(role!=null) {
				if (role.equals("admin")) { 
					Admin adminUser = userService.getAdmin(username, password);
				if(adminUser!=null) {
						HttpSession session=request.getSession();
						session.setAttribute("user", adminUser);
						RequestDispatcher rd=request.getRequestDispatcher("admin.jsp");
						rd.forward(request, response);
					}
				}
				
				else if (role.equals("manager")) { 
					Manager mngUser = userService.getManager(username, password);
					if(mngUser!=null) {
						HttpSession session=request.getSession();
						session.setAttribute("user", mngUser);
						RequestDispatcher rd=request.getRequestDispatcher("manager.jsp");
						rd.forward(request, response);
					}
				}
				
				else if (role.equals("customer")) { 
					Customer custUser = userService.getCustomer(username, password);
					if(custUser!=null) {
						HttpSession session=request.getSession();
						session.setAttribute("user", custUser);
						RequestDispatcher rd=request.getRequestDispatcher("customer.jsp");
						rd.forward(request, response);
						}
				}
				
				else if (role.equals("engineer")) { 
					Engineer engUser = userService.getEngineer(username, password);
					if(engUser!=null) {
						HttpSession session=request.getSession();
						session.setAttribute("user", engUser);
						RequestDispatcher rd=request.getRequestDispatcher("engineer.jsp");
						rd.forward(request, response);
						}
				}
				
				else { 
					RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
					request.setAttribute("msg", "Username/Password is invalid role");
					rd.forward(request, response);
				} 
				} else { 
					RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
					request.setAttribute("msg", "Username/Password is invalid");
					rd.forward(request, response);
				}
			}

}

