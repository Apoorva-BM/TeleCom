package com.telecom.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.telecom.model.UserModel;
import com.telecom.service.UserService;



@WebServlet("/register")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserService userService = new UserService();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String role =request.getParameter("role");
		UserModel userModel=new UserModel(username, password,role);
		if("admin".equals(role)) {userService.addAdmin(userModel);RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
		rd.forward(request, response);}
		else if("manager".equals(role)) {userService.addManager(userModel);RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
		rd.forward(request, response);}
		else if("engineer".equals(role)) {userService.addEngineer(userModel);RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
		rd.forward(request, response);}
		else if("customer".equals(role)) {userService.addCustomer(userModel);RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
		rd.forward(request, response);}
		else { RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
		request.setAttribute("msg", "Username/Password is invalid");
		rd.forward(request, response); }
	
	}

}


