package com.telecom.model;

public class ComplaintModel {

	private String complaintType;
	
	private String description;
	
	public ComplaintModel() {
		// TODO Auto-generated constructor stub
	}

	public ComplaintModel(String complaintType, String description) {
		super();
		this.complaintType = complaintType;
		this.description = description;
	}

	public String getComplaintType() {
		return complaintType;
	}

	public void setComplaintType(String complaintType) {
		this.complaintType = complaintType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
