package com.telecom.Config;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

import com.telecom.entity.Address;
import com.telecom.entity.Admin;
import com.telecom.entity.Complaint;
import com.telecom.entity.Customer;
import com.telecom.entity.Engineer;
import com.telecom.entity.Manager;

public class HibConfig {
	public static SessionFactory getSessionFactory() {
		Configuration configuration = new Configuration();
		Properties properties = new Properties();
		properties.put(Environment.DRIVER, "com.mysql.cj.jdbc.Driver");
		properties.put(Environment.URL, "jdbc:mysql://localhost:3306/telecom");
		properties.put(Environment.USER, "root");
		properties.put(Environment.PASS, "roots");
		properties.put(Environment.SHOW_SQL, true);
		properties.put(Environment.FORMAT_SQL, true);
		properties.put(Environment.HBM2DDL_AUTO, "update");
		configuration.setProperties(properties);
		configuration.addAnnotatedClass(Address.class);
		configuration.addAnnotatedClass(Admin.class);
		configuration.addAnnotatedClass(Complaint.class);
		configuration.addAnnotatedClass(Customer.class);
		configuration.addAnnotatedClass(Engineer.class);
		configuration.addAnnotatedClass(Manager.class);
		SessionFactory factory = configuration.buildSessionFactory();
		return factory;
	}
}
