package com.telecom.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Complaint {
 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int complaintId;
	
	private String complaintType;
	
	private String description;
	
	 @ManyToOne
	    @JoinColumn(name = "customer_id")
	    private Customer customer;
	 
	 @ManyToOne
	    @JoinColumn(name = "manager_id")
	    private Manager manager;
	 
	 @ManyToOne
	    @JoinColumn(name = "engineer_id")
	    private Engineer engineer;
	
	public Complaint() {
		// TODO Auto-generated constructor stub
	}

	public Complaint(int complaintId, String complaintType, String description, Customer customer, Manager manager,
			Engineer engineer) {
		super();
		this.complaintId = complaintId;
		this.complaintType = complaintType;
		this.description = description;
		this.customer = customer;
		this.manager = manager;
		this.engineer = engineer;
	}

	public int getComplaintId() {
		return complaintId;
	}

	public void setComplaintId(int complaintId) {
		this.complaintId = complaintId;
	}

	public String getComplaintType() {
		return complaintType;
	}

	public void setComplaintType(String complaintType) {
		this.complaintType = complaintType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Manager getManager() {
		return manager;
	}

	public void setManager(Manager manager) {
		this.manager = manager;
	}

	public Engineer getEngineer() {
		return engineer;
	}

	public void setEngineer(Engineer engineer) {
		this.engineer = engineer;
	}

	
}
