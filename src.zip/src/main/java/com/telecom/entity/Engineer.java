package com.telecom.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.telecom.model.EngineerModel;

@Entity
public class Engineer {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int engineerID;
	
	private String engUserName;
	
	private String engPassword;
	
	private String engEmail;
	
	private int engPhoneNumnber;
	
	@ManyToOne
    @JoinColumn(name = "addressID")
    private Address engAddress;
	
	private int engPincode;
	
	public Engineer() {
		// TODO Auto-generated constructor stub
	}

	public Engineer(int engineerID, String engUserName, String engPassword, String engEmail, int engPhoneNumnber,
			Address engAddress, int engPincode) {
		super();
		this.engineerID = engineerID;
		this.engUserName = engUserName;
		this.engPassword = engPassword;
		this.engEmail = engEmail;
		this.engPhoneNumnber = engPhoneNumnber;
		this.engAddress = engAddress;
		this.engPincode = engPincode;
	}

	public Engineer(EngineerModel model) {
        this.engUserName = model.getUserName();// Assuming getName() method exists in CustomerModel
        this.engPassword = model.getPassword();// Assuming getAddress() method exists in CustomerModel
       
	}
	
	public int getEngineerID() {
		return engineerID;
	}

	public void setEngineerID(int engineerID) {
		this.engineerID = engineerID;
	}

	public String getEngUserName() {
		return engUserName;
	}

	public void setEngUserName(String engUserName) {
		this.engUserName = engUserName;
	}

	public String getEngPassword() {
		return engPassword;
	}

	public void setEngPassword(String engPassword) {
		this.engPassword = engPassword;
	}

	public String getEngEmail() {
		return engEmail;
	}

	public void setEngEmail(String engEmail) {
		this.engEmail = engEmail;
	}

	public int getEngPhoneNumnber() {
		return engPhoneNumnber;
	}

	public void setEngPhoneNumnber(int engPhoneNumnber) {
		this.engPhoneNumnber = engPhoneNumnber;
	}

	public Address getEngAddress() {
		return engAddress;
	}

	public void setEngAddress(Address engAddress) {
		this.engAddress = engAddress;
	}

	public int getEngPincode() {
		return engPincode;
	}

	public void setEngPincode(int engPincode) {
		this.engPincode = engPincode;
	}
	
	
}
