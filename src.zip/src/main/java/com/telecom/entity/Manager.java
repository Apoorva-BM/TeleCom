package com.telecom.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.telecom.model.ManagerModel;



@Entity
public class Manager {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int managerID;
	
	private String mngUserName;
	
	private String mngPassword;
	
	private int mngPinCode;
	
	private int mngPhoneNumber;
	
	private String mngEmail;
	
	@ManyToOne
    @JoinColumn(name = "addressID")
    private Address address;
	
	public Manager() {
		// TODO Auto-generated constructor stub
	}

	public Manager(ManagerModel model) {
		this.mngUserName = model.getUserName();
		this.mngPassword = model.getPassword();
	}
	
	public Manager(int managerID, String mngUserName, String mngPassword, int mngPinCode, int mngPhoneNumber,
			String mngEmail, Address address) {
		super();
		this.managerID = managerID;
		this.mngUserName = mngUserName;
		this.mngPassword = mngPassword;
		this.mngPinCode = mngPinCode;
		this.mngPhoneNumber = mngPhoneNumber;
		this.mngEmail = mngEmail;
		this.address = address;
	}

	public int getManagerID() {
		return managerID;
	}

	public void setManagerID(int managerID) {
		this.managerID = managerID;
	}

	public String getMngUserName() {
		return mngUserName;
	}

	public void setMngUserName(String mngUserName) {
		this.mngUserName = mngUserName;
	}

	public String getMngPassword() {
		return mngPassword;
	}

	public void setMngPassword(String mngPassword) {
		this.mngPassword = mngPassword;
	}

	public int getMngPinCode() {
		return mngPinCode;
	}

	public void setMngPinCode(int mngPinCode) {
		this.mngPinCode = mngPinCode;
	}

	public int getMngPhoneNumber() {
		return mngPhoneNumber;
	}

	public void setMngPhoneNumber(int mngPhoneNumber) {
		this.mngPhoneNumber = mngPhoneNumber;
	}

	public String getMngEmail() {
		return mngEmail;
	}

	public void setMngEmail(String mngEmail) {
		this.mngEmail = mngEmail;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	
	
}
