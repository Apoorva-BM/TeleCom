package com.telecom.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.telecom.model.CustomerModel;

@Entity
public class Customer {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int customerID;
	
	private String customerUserName;
	
	private String customerPassword;
	
	private String customerEmail;
	
	private String customerPhoneNumber;
	
	private String feedback;
	
	private String customerName;
	
	@ManyToOne
    @JoinColumn(name = "addressID")
    private Address custAddress;
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Customer(int customerID, String customerUserName, String customerPassword, String customerEmail,
			String customerPhoneNumber, String feedback, String customerName, Address custAddress) {
		super();
		this.customerID = customerID;
		this.customerUserName = customerUserName;
		this.customerPassword = customerPassword;
		this.customerEmail = customerEmail;
		this.customerPhoneNumber = customerPhoneNumber;
		this.feedback = feedback;
		this.customerName = customerName;
		this.custAddress = custAddress;
	}

	public Customer(CustomerModel customerModel) {
        this.customerUserName = customerModel.getUserName() ;// Assuming getName() method exists in CustomerModel
        this.customerPassword = customerModel.getPassword(); // Assuming getAddress() method exists in CustomerModel
       
	}
        
	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public String getCustomerUserName() {
		return customerUserName;
	}

	public void setCustomerUserName(String customerUserName) {
		this.customerUserName = customerUserName;
	}

	public String getCustomerPassword() {
		return customerPassword;
	}

	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getCustomerPhoneNumber() {
		return customerPhoneNumber;
	}

	public void setCustomerPhoneNumber(String customerPhoneNumber) {
		this.customerPhoneNumber = customerPhoneNumber;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Address getCustAddress() {
		return custAddress;
	}

	public void setCustAddress(Address custAddress) {
		this.custAddress = custAddress;
	}
	
	
	
	
	
}
